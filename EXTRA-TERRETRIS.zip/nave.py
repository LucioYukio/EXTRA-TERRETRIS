from body import *
from body import Mouse
from pplay.sprite import Sprite
from pplay.window import Window
from projectile import Projectile
from screen import Mouse

DEFAULT_NAVE_SIZE : Vector2 = Vector2(69, 80)
DEFAULT_NAVE_HITBOX : Vector2 = Vector2(20, 30)

class Bullet(Projectile):
    def __init__(self, img: str, tab: int, mouse: Mouse, objs: list):
        super().__init__(img, 6, 8, tab, mouse, objs)
        self.total_frames = 4
        self.frame_duration = 0.1
        
        self.categorie = "bullet"

class NaveBullet(Bullet):
    def __init__(self, tab: int, mouse: Mouse, objs: list):
        super().__init__("assets/images/disparo_player.png", tab, mouse, objs)
        self.tags.append("player_projectile")
        self.velocity.y = -600
        
        self.categorie = "nave bullet"

class Rastro(Object):
    def __init__(self, tab: int, mouse: Mouse, rastros: int, tela: Screen):
        # implementar intervalo: espera "intervalo" cooldown para fazer as trocas
        super().__init__("assets/images/empty_pixel.png",8, 8, tab, mouse)
        self.screen = tela
        
        self.rastros : List[Object] = [] # do mais fino pro mais grosso
        self.qtd = rastros
        
        self.offset : Vector2 = Vector2(0,0)
        
        self.interval : float = 0.075 # interval between rastros changing position
        self.cooldown : float = 0 # changing rastros cooldown
        
        self.destroy_out_of_h_bounds = False
        self.destroy_out_of_v_bounds = False
        self.keep_in_bounds = False
        
        for i in range(rastros):
            rastro : Object = tela.add_object(Object(
                "assets/images/rastro.png",
                int(self._width * i / rastros + 2),
                int(self._height * i / rastros + 2),
                tab,
                mouse,
                2
            ))
            rastro.destroy_out_of_h_bounds = False
            rastro.destroy_out_of_v_bounds = False
            rastro.horizontal_bounds = self.horizontal_bounds
            rastro.categorie = "rastrinho"
            rastro.keep_in_bounds = False
            self.rastros.append(rastro)
        
        self.categorie = "rastro"
    
    def update(self):
        self.cooldown += self.delta_time
        if self.cooldown > self.interval:
            self.advance_rastro()
            self.cooldown = 0
    
    def propagate_bounds(self):
        for r in self.rastros:
            r.horizontal_bounds = self.horizontal_bounds
            pass
    
    def advance_rastro(self):
        if self.qtd <= 0:
            return 
        self.rastros[-1].x = self.x + self.offset.x - self._width/2
        self.rastros[-1].y = self.y + self.offset.y - self._height + 1
        for i in range(self.qtd - 1):
            self.rastros[i].x = self.rastros[i+1].x + self.rastros[i+1].get_width()/2 - self.rastros[i].get_width()/2
            self.rastros[i].y = self.rastros[i+1].y + self.rastros[i+1].get_height()/2 - self.rastros[i].get_height()/2
    
    def render(self, window: Window):
        for r in self.rastros:
            r.render(window)
    
    def destroy(self):
        for rastro in self.rastros:
            self.screen.remove_object_by_id(rastro.get_id())

class Nave(Body):
    
    rastro : Rastro
    
    def __init__(self, image: str, width: int, height: int, tab: int, mouse: Mouse, objs: list, keyboard: k.Keyboard, tela: Screen, v_parts: int = 16):
        self.screen : Screen = tela
        super().__init__(image, width, height, tab, mouse, objs, v_parts)
        self.tags.append("player")
        self.damage_from_tags = {"enemy_projectile"}
        self.keyboard : k.Keyboard = keyboard
        self.speed : float = 300
        self.direction : Vector2 = Vector2(0,0)
        self.hitbox = DEFAULT_NAVE_HITBOX.copy()
        
        """Stats vars"""
        self.health : float = 9999
        # tempo ate poder levar dano de novo
        self.damage_interval : float = 1
        self.damage_cooldown : float = 0
        
        """Bullet vars"""
        self.default_shooting_interval : float = 0.2
        self.shooting_interval : float = self.default_shooting_interval
        self.shooting_cooldown : float = 0
        self.bullets : List[Bullet] = []
        
        """Teclas"""
        self.UP    : str = "up"
        self.DOWN  : str = "down"
        self.LEFT  : str = "left"
        self.RIGHT : str = "right"
        self.SHOOT : str = "space"
        self.POWER : str = "x"
        # Se esta apertando left e right e se esta apertando up and down, para x e y respectivamente
        self.pressing_both : Vector2 = Vector2(0,0)
        
        self.categorie = "nave"
    
    def shoot(self):
        self.bullets.append(self.screen.add_object(NaveBullet(self._tab, self._mouse, self.objs)))
        self.bullets[-1].x = self.x + self.get_width()/2 - self.bullets[-1].get_width()/2
        self.bullets[-1].y = self.y - self.bullets[-1].get_height() + 5
        self.bullets[-1].horizontal_bounds = self.horizontal_bounds

    def spawn_rastro(self):
        self.rastro = self.screen.add_object(Rastro(self._tab, self._mouse, 8, self.screen))
        self.rastro.horizontal_bounds = self.horizontal_bounds
        for r in self.rastro.rastros:
            r.horizontal_bounds = self.horizontal_bounds
        self.apply_rastro_offset()

    def apply_rastro_offset(self):
        try:    self.rastro
        except: self.spawn_rastro()
        # para baixo da nave
        self.rastro.offset = Vector2(self.get_width()/2, self.get_height())
    
    def set_height(self, height: float):
        super().set_height(height)
        self.apply_rastro_offset()
    
    def set_width(self, width: float):
        super().set_width(width)
        self.apply_rastro_offset()
    
    def get_direction(self):
        # Se apertar ambos os botoes, trocar direcao
        direction_x = self.keyboard.key_pressed(self.RIGHT) - self.keyboard.key_pressed(self.LEFT)
        if self.keyboard.key_pressed(self.RIGHT) and self.keyboard.key_pressed(self.LEFT):
            if self.pressing_both.x == 0:
                # pressionando ambos, mudar para a mais recente
                self.pressing_both.x = 1
                self.direction.x *= -1
            if self.direction.x < 0:
                self.direction.x = -1
            else:
                self.direction.x = 1
                
        else:
            self.pressing_both.x = False
            self.direction.x = direction_x
        
        direction_y = self.keyboard.key_pressed(self.DOWN) - self.keyboard.key_pressed(self.UP)
        if self.keyboard.key_pressed(self.DOWN) and self.keyboard.key_pressed(self.UP):
            if self.pressing_both.y == 0:
                # pressionando ambos, mudar para a mais recente
                self.pressing_both.y = 1
                self.direction.y *= -1
            if self.direction.y < 0:
                self.direction.y = -1
            else:
                self.direction.y = 1
        else:
            self.pressing_both.y = False
            self.direction.y = direction_y
        
    def check_shoot(self):
        if self.keyboard.key_pressed(self.SHOOT) and self.shooting_cooldown <= 0:
            self.shoot()
            self.shooting_cooldown = self.shooting_interval
    
    def destroy_rastro(self):
        if not hasattr(self, "rastro"):
            return
        self.rastro.destroy()
        self.screen.remove_object_by_id(self.rastro.get_id())
    
    def destroy(self):
        self.destroy_rastro()

    def check_damage(self):
        colliders = self.get_colliders()
        for c in colliders:
            if isinstance(c, Projectile):
                if self.damage_from_tags and not any(tag in c.tags for tag in self.damage_from_tags):
                    continue
                if c in self.bullets:
                    continue
                # receive damage
                self.health -= c.get_damage()
                c.wants_to_die = c.destroy_on_hit
        if self.health <= 0:
            self.screen.remove_object_by_id(self.get_id())

    def destroy_bullet(self, bullet: Bullet):
        self.screen.remove_object_by_id(bullet.get_id())
        self.bullets.remove(bullet)
    
    def propagate_bounds(self):
        self.rastro.horizontal_bounds = self.horizontal_bounds
        self.rastro.propagate_bounds()
    
    def update(self):
        if self.rastro.horizontal_bounds != self.horizontal_bounds:
            self.propagate_bounds()
        
        self.get_direction()
        
        self.direction.normalize()
        self.velocity.x = self.direction.x * self.speed
        self.velocity.y = self.direction.y * self.speed
        
        self.check_shoot()
        self.check_damage()
        
        for b in self.bullets:
            if b.wants_to_die or (b.destroy_out_of_screen and b.out_of_screen):
                self.destroy_bullet(b)
        
        self.shooting_cooldown = max(self.shooting_cooldown - self.delta_time, 0)
        
        self.rastro.x = self.x
        self.rastro.y = self.y
        self.rastro.delta_time = self.delta_time
        self.rastro.update()
        
        super().update()
