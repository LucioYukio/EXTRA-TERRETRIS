
    while time.perf_counter_ns() < target:
        print(time.perf_counter_ns())