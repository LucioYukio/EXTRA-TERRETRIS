# usar cada tab como se fosse uma janela
# da pra trocar de tab facilmente
# as tabs tem um offset muito grande e sao desenhadas so quando selecionadas
import math
from typing import List, Tuple

from pygame.surface import Surface

import pplay.window as w
import pplay.gameobject as go
import pplay.gameimage as gi
import pplay.sprite as s
import pplay.keyboard as k
import pplay.mouse as m
import pplay.gameobject as go
import pplay.window as w
import pygame.transform

# TODO make a global delta_time and time elapsed variables

REF_RES = (1600, 900) # tamanhos seram calculados em relacao a essa variavel

res_scale : List[float] = [1,1]

def update_res_scale(new_res : List[float]):
    global REF_RES, res_scale
    res_scale[0] = new_res[0]/REF_RES[0]
    res_scale[1] = new_res[1]/REF_RES[1]
    print("nova res_scale:", res_scale)


def clamp(x, min, max):
    if x < min:
        return min
    if x > max:
        return max
    return x

class Vector2:
    def __init__(self, x : float = 0, y : float = 0):
        self.x = x
        self.y = y

    def length(self):
        return math.sqrt(self.x**2 + self.y**2)

    def normalize(self):
        length = self.length()
        if length == 0: return
        self.x /= length
        self.y /= length

    def copy(self):
        return Vector2(self.x, self.y)
        
        
    def __repr__(self) -> str:
        return f"({self.x}, {self.y})"


class Mouse(m.Mouse):
    def __init__(self):
        super().__init__()
        self._ticks_pressed : int = 0

    def update(self):
        if self.is_button_pressed(1) or self.is_button_pressed(2) or self.is_button_pressed(3):
            self._ticks_pressed += 1
        else:
            self._ticks_pressed = 0

    def is_button_just_pressed(self, button: int):
        self.update()
        return (self._ticks_pressed == 1) and self.is_button_pressed(button)


class Object:
    _width : int = 0
    _height : int = 0
    ## se diferente de -1, considera esse valor como limites verticais
    horizontal_bounds : Vector2 = Vector2(-1, -1)
    ## se diferente de -1, considera esse valor como limites verticais
    vertical_bounds : Vector2 = Vector2(-1, -1)
    ## precisa ser atualizado pela screen antes do update
    out_of_h_bounds : bool = False
    ## precisa ser atualizado pela screen antes do update
    out_of_v_bounds : bool = False
    def __init__(self, image : str, width : int, height: int, tab: int, mouse: Mouse, v_parts : int = 1):
        self._mouse  : Mouse    = mouse

        self.image : str = image
        self.sprites : List[s.Sprite] = []
        # how many vertical parts the object has, used for rendering
        self.v_parts : int = v_parts

        """tab da qual o objeto pertence"""
        self._tab    : int      = tab

        """Coordenadas locais"""
        self.x : float = 0
        self.y : float = 0
        self.z : int   = 0 # ordem de desenho; camada; maior valor eh desenhado na frente

        """Tamanho local"""
        self.set_width(width)
        self.set_height(height)


        """variaveis de animacao"""
        self._animation_time_elapsed : float = 0
        self.frame_duration : float = 1 # em segundos, maior que 0
        self.total_frames : int = 1

        self.build_sprites()

        self.visible : bool     = True
        self.enabled : bool     = True
        ## precisa ser atualizado pela screen antes do update
        self.delta_time : float = 0
        ## precisa ser atualizado pela screen antes do update
        self.out_of_screen : bool = False
        ## se diferente de -1, considera esse valor como limites horizontais
        self.horizontal_bounds : Vector2 = Vector2(-1, -1)
        ## se diferente de -1, considera esse valor como limites verticais
        self.vertical_bounds : Vector2 = Vector2(-1, -1)
        ## precisa ser atualizado pela screen antes do update
        self.out_of_h_bounds : bool = False
        ## precisa ser atualizado pela screen antes do update
        self.out_of_v_bounds : bool = False
        ## precisa ser atualizado pela screen antes do update
        self.screen_size : Vector2 = Vector2(1600, 900)
        self.keep_in_bounds : bool = True

        self.destroy_out_of_h_bounds : bool = False
        self.destroy_out_of_v_bounds : bool = False
        self.categorie : str = ""

        self.tags = []

        self._id     : int      = 0


    def get_tab(self):
        return self._tab

    def set_tab(self, tab: int):
        self._tab = tab

    def get_id(self):
        return self._id

    def set_id(self, id: int):
        self._id = id

    def get_width(self):
        return self._width

    def set_width(self, width: float):
        self._width = int(width * res_scale[0])
        self.update_sprites()

    def get_height(self):
        return self._height

    def set_height(self, height: float):
        self._height = int(height * res_scale[1])
        self.update_sprites()

    def get_center(self):
        return Vector2(self.x + self.get_width()/2, self.y + self.get_height()/2)

    def build_sprites(self):
        self.sprites.clear()
        for i in range(self.v_parts):
            spr = s.Sprite(self.image, self.total_frames)
            spr.playing = False
            self.sprites.append(spr)
        self.update_sprites()
    
    def get_h_bounds(self):
        h_bounds : List[float] = []
        
        if self.horizontal_bounds.x != -1:
            h_bounds.append(self.horizontal_bounds.x)
        else:
            h_bounds.append(0)
        
        if self.horizontal_bounds.y != -1:
            h_bounds.append(self.horizontal_bounds.y)
        else:
            h_bounds.append(self.screen_size.x)
        
        return h_bounds
    
    # checks to see if the part is inside h_bounds
    def is_v_part_in_bounds(self, v_part : int):
        coords : Vector2 = Vector2(
            self.x + (self.get_width()/self.v_parts) * v_part,
            self.y
        )
        size : Vector2 = Vector2(
            self.get_width()/self.v_parts,
            self.get_height()
        )
        
        h_bounds = self.get_h_bounds()
        
        if coords.x > h_bounds[1] - 1 or coords.x + size.x < h_bounds[0] + 1:
            return False
        return True


    def apply_coords(self, offset_x : float, offset_y : float):
        for i in range(self.v_parts):
            self.sprites[i].x = offset_x + self.x + (self.get_width()/self.v_parts) * i
            self.sprites[i].y = offset_y + self.y

    def animate(self):
        """Aplica a logica de animacao. Chamar em todo update."""
        self._animation_time_elapsed += self.delta_time
        return
        curr_frame : int = int(self._animation_time_elapsed / self.frame_duration) % self.total_frames
        for i in range(self.v_parts):
            spr = self.sprites[i]
            if spr.curr_frame != (self.v_parts * i) + (self.v_parts * curr_frame):
                spr.set_curr_frame(spr.curr_frame)

    def render(self, window: w.Window):
        # check what sprites in this object are in bounds and render them.
        visible_sprites : List[s.Sprite] = []
        for i in range(self.v_parts):
            if self.is_v_part_in_bounds(i):
                self.sprites[i].draw()

    def update_sprites(self):
        """Mudar o tamanho das imagens de acordo com o
        width e height"""
        # TODO corrigir pedacinho da direita nao aparecendo
        i : int = 0
        for spr in self.sprites:
            spr.image = pygame.transform.scale(spr.image, ((self.get_width() + self.v_parts) * self.total_frames, self.get_height()))
            spr.width = int(self.get_width()/self.v_parts)
            spr.width += 1
            spr.height = int(self.get_height())
            spr.curr_frame = i
            i += 1

    def update(self):
        """Para criancas terem comportamento por frame"""
        self.screen_size.x = REF_RES[0] * res_scale[0]
        self.screen_size.y = REF_RES[1] * res_scale[1]
        
        self.animate()
        for spr in self.sprites:
            spr.update()

    # call this before "destroying" the object, for custom behaviour
    def destroy(self):
        pass

    def is_hovered(self):
        for spr in self.sprites:
            if self._mouse.is_over_object(spr) and self.enabled:
                return True
        return False

    def is_pressed(self, button: int = 1):
        return self.is_hovered() and self._mouse.is_button_pressed(1)

    def is_just_pressed(self, button: int = 1):
        return self.is_hovered() and self._mouse.is_button_just_pressed(button)
    
class Screen:
    global res_scale
    def __init__(self, width : int, height : int):
        self.window      : w.Window     = w.Window(width, height)
        self._objs       : List         = []
        self._tab        : int          = 0
        self.bg_image    : str          = ""
        self._id_counter : int          = 0
        self.mouse       : Mouse        = Mouse()
        # one color per tab
        self.bg_colors = {}
        # one image per tab
        self.bg_imgs = {}
        
        self.bg : gi.GameImage = gi.GameImage("assets/images/black_pixel.png")
        
        self.ticks : int = 0
        self.time_elapsed : float = 0
        
        self.set_tab(0)
        

    def set_tab(self, tab: int):
        self._tab = tab
        self.set_bg_image()
    
    def get_tab(self):
        return self._tab
    
    def set_bg_image(self):
        if self.bg_imgs.get(self._tab):
            self.bg.image = pygame.transform.scale(gi.GameImage(self.bg_imgs[self._tab]).image, (self.window.width, self.window.height))

    def set_title(self, title: str):
        self.window.set_title(title)

    def add_object(self, obj : Object):
        obj.set_id(self._id_counter)
        self._id_counter += 1
        self._objs.append(obj)
        return self._objs[-1]
    
    def remove_object_by_id(self, id: int):
        for obj in self._objs:
            if obj.get_id() == id:
                obj.destroy()
                self._objs.remove(obj)
                return

    def clear_tab(self, tab: int):
        """Apagar todo objeto da tab passada"""
        for obj in self._objs:
            if obj.get_tab() == tab:
                self.remove_object_by_id(obj.get_id())

    def fps(self):
        if self.ticks == 0 or self.time_elapsed == 0:
            return 0
        fps_medio = 1 / (self.time_elapsed/self.ticks)
        fps_atual = 1 / self.window.delta_time()
        #if abs(fps_atual - fps_medio) > 10: # se fps atual muito diferente de medio
        #    return fps_atual
        return fps_medio

    def update(self):
        if self.window.delta_time() > 0:
            self.time_elapsed += self.window.delta_time()
            self.ticks += 1
        
        if self.bg_colors.get(self._tab):
            self.window.set_background_color(self.bg_colors.get(self._tab, 0))
        else:
            self.window.set_background_color("black")
            
        if self.bg_imgs.get(self._tab):
            self.bg.y = self.window.time_elapsed()/750
            self.bg.draw()
        
        # aplicar logica
        ids_to_remove : List[int] = []
        for obj in self._objs:
            if not isinstance(obj, Object):
                return
            # da pra jogar todos os objetos nao usados para o mesmo lugar no limbo, tambem...
            tab_offset : float = (obj.get_tab() - self._tab) * 5000
            obj.apply_coords(tab_offset, tab_offset)
            if obj.visible and tab_offset == 0 and obj:
                # objeto ativo, atualizar
                obj.delta_time = self.window.delta_time()
                
                h_bounds : Vector2 = Vector2(
                    0 if obj.horizontal_bounds.x == -1 else obj.horizontal_bounds.x,
                    self.window.width if obj.horizontal_bounds.y == -1 else obj.horizontal_bounds.y,
                )

                v_bounds : Vector2 = Vector2(
                    0 if obj.vertical_bounds.x == -1 else obj.vertical_bounds.x,
                    self.window.height if obj.vertical_bounds.y == -1 else obj.vertical_bounds.y,
                )
                
                obj.update()
                
                if obj.keep_in_bounds:
                    obj.x = clamp(obj.x, h_bounds.x, h_bounds.y - obj.get_width())
                    obj.y = clamp(obj.y, v_bounds.x, v_bounds.y - obj.get_height())
                else:
                    obj.out_of_h_bounds = obj.x > h_bounds.y or\
                        obj.x + obj.get_width() < h_bounds.x
                    obj.out_of_v_bounds = obj.y > v_bounds.y or\
                        obj.y + obj.get_height() < v_bounds.x

                obj.out_of_screen = ((obj.x + obj.get_width() < h_bounds.x) or (obj.x > h_bounds.y)) or\
                    ((obj.y + obj.get_height() < v_bounds.x) or (obj.y > v_bounds.y))

                if obj.out_of_h_bounds and obj.destroy_out_of_h_bounds or\
                obj.out_of_v_bounds and obj.destroy_out_of_v_bounds:
                    ids_to_remove.append(obj.get_id())

        for obj_id in ids_to_remove:
            self.remove_object_by_id(obj_id)
        
        # renderizar
        layer : int = 0
        render_buffer = self._objs.copy()
        while len(render_buffer): # enquanto sobrarem elementos
            for obj in render_buffer.copy():
                if not isinstance(obj,Object): return
                if obj.z == layer:
                    render_buffer.remove(obj)
                    if obj.get_tab() == self.get_tab() and not obj.out_of_v_bounds:
                        obj.render(self.window) # desenhar elementos dessa camada
            layer += 1
        
        self.window.update()