from body import *
from pplay.sprite import Sprite
from screen import Mouse

class Projectile(Body):
    def __init__(self, image: str, width: int, height: int, tab: int, mouse: Mouse, objs: list):
        super().__init__(image, width, height, tab, mouse, objs)
        self.keep_in_bounds = False
        self.damage : float = 1
        # destruir se sair da tela
        self.destroy_out_of_screen : bool = True
        self.destroy_on_hit : bool = True
        self.wants_to_die : bool = False
        self.tags.append("projectile")
        
        self.categorie = "projectile"
    
    def get_damage(self):
        return self.damage