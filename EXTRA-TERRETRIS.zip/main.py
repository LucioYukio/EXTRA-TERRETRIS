from random import randrange
import time

from screen import *
from button import *
from body import *
from nave import *
from enemy import *
from tetrisgrid import *

TELA_W = 1600
TELA_H = 900
update_res_scale([TELA_W, TELA_H])
tela = Screen(TELA_W, TELA_H)
tela.set_title("Extraterretris")

mouse   = Mouse()
teclado = k.Keyboard()

# variaveis de botao
botoes_gap  = 20
botoes_size = 45

DIF_FACIL   = 0.5
DIF_MEDIO   = 1
DIF_DIFICIL = 2
dificuldade = DIF_MEDIO

# cima, baixo, esquerda, direita, tiro, poder
control_esquemes = [
    ["up", "down", "left", "right", "n", "m"], 
    ["w", "s", "a", "d", "space", "alt"]
]

enemy_spawn_interval : float = 2
enemy_spawn_cooldown : float = 0
MAX_ENEMY_COUNT : int = 8 *2
enemy_horizontal_padding : int = 8 # padding to account for when spawning enemies

#---------------- FUNCOES ---------------------------
def spawn_enemy(x: float, tab: int, horizontal_bounds : Tuple[int, int]):
    enemy : EnemySin = tela.add_object(EnemySin(
        int(DEFAULT_NAVE_SIZE.x),
        int(DEFAULT_NAVE_SIZE.y),
        tab,
        mouse,
        tela._objs,
        teclado, tela
    ))
    x = clamp(x, 0, tela.window.width - enemy.get_width())
    enemy.x = x
    enemy.y = -enemy.get_height() + 1
    enemy.horizontal_bounds = Vector2(horizontal_bounds[0], horizontal_bounds[1])
    enemy.vertical_bounds = Vector2(-enemy.get_height(), tela.window.height + enemy.get_height())


def enemy_count():
    count : int = 0
    for obj in tela._objs:
        if isinstance(obj, Enemy):
            count += 1
    return count

#---------------- TABS -----------------

TAB_JOGO = 0

tela.bg_imgs[TAB_JOGO] = "assets/images/double_bg.png"

nave1 : Nave = tela.add_object(Nave(
    "assets/images/nave1.png",
    int(DEFAULT_NAVE_SIZE.x),
    int(DEFAULT_NAVE_SIZE.y),
    TAB_JOGO,
    tela.mouse,
    tela._objs,
    teclado,
    tela
 ))
nave1.x = tela.window.width/4 - nave1.get_width()/2
nave1.y = TELA_H - nave1.get_height() - 8
nave1.horizontal_bounds.y = tela.window.width/2
nave1.UP, nave1.DOWN, nave1.LEFT, nave1.RIGHT, nave1.SHOOT, nave1.POWER = control_esquemes[1]
nave1.z = 1

nave2 : Nave = tela.add_object(Nave(
    "assets/images/nave2.png",
    int(DEFAULT_NAVE_SIZE.x),
    int(DEFAULT_NAVE_SIZE.y),
    TAB_JOGO,
    tela.mouse,
    tela._objs,
    teclado,
    tela
))
nave2.x = tela.window.width/4 + tela.window.width/2 - nave2.get_width()/2
nave2.y = tela.window.height - nave2.get_height() - 8
nave2.horizontal_bounds.x = tela.window.width/2
nave2.UP, nave2.DOWN, nave2.LEFT, nave2.RIGHT, nave2.SHOOT, nave2.POWER = control_esquemes[0]
nave2.z = 1

TAB_TETRIS = 1

tetris_grid1 : TetrisGrid = tela.add_object(TetrisGrid(Vector2(42,42), 20, 10, TAB_TETRIS, mouse))
tetris_grid1.FILLED = "assets/images/tile_filled_green.png"
tetris_grid1.x = 200
tetris_grid1.y = 42
tetris_grid1.build_grids()

tetris_grid2 : TetrisGrid = tela.add_object(TetrisGrid(Vector2(42,42), 20, 10, TAB_TETRIS, mouse))
tetris_grid2.FILLED = "assets/images/tile_filled_purple.png"
tetris_grid2.x = 1000
tetris_grid2.y = 42
tetris_grid2.build_grids()

# preencher para demonstracao ---------
for i in range(10):
    tetris_grid1._matrix[-1][i] = 1
    tetris_grid1._matrix[-2][i] = 2
    tetris_grid1._matrix[-3][i] = 2
    tetris_grid1._matrix[-4][i] = 2
    
    tetris_grid2._matrix[-1][i] = 1
    tetris_grid2._matrix[-2][i] = 1
    tetris_grid2._matrix[-3][i] = 2
    tetris_grid2._matrix[-4][i] = 2
tetris_grid2._matrix[-3][4] = 0
tetris_grid2._matrix[-4][4] = 0
tetris_grid2._matrix[-4][5] = 0
tetris_grid2._matrix[-4][6] = 0
tetris_grid2._matrix[-5][1] = 2

tetris_grid1._matrix[-3][2] = 0
tetris_grid1._matrix[-4][4] = 0
tetris_grid1._matrix[-4][7] = 0
tetris_grid1._matrix[-4][3] = 0
    
tetris_grid1._matrix[4][5] = 2
tetris_grid1._matrix[5][5] = 2
tetris_grid1._matrix[6][5] = 2
tetris_grid1._matrix[7][5] = 2

tetris_grid2._matrix[8][1] = 2
tetris_grid2._matrix[8][2] = 2
tetris_grid2._matrix[8][3] = 2
tetris_grid2._matrix[9][2] = 2
# -----------

# ------------------------- Game Loop ----------------------------

tela.set_tab(0)
while True:
    #----------------------- Callback Dos Botoes ----------------------
    # --------
    
    #----------------------- Enemy Spawn ------------------------------
    if enemy_spawn_cooldown <= 0 and enemy_count() + 2 <= MAX_ENEMY_COUNT:
        x : float = randrange(enemy_horizontal_padding, int(tela.window.width/2))
        spawn_enemy(x, TAB_JOGO, (-100, int(tela.window.width/2)))
        x : float = randrange(int(tela.window.width/2) + enemy_horizontal_padding, int(tela.window.width) - enemy_horizontal_padding)
        spawn_enemy(x, TAB_JOGO, (int(tela.window.width/2), int(tela.window.width) + 100))
        enemy_spawn_cooldown = enemy_spawn_interval
    # --------
    
    # drain cooldowns
    enemy_spawn_cooldown = max(enemy_spawn_cooldown - tela.window.delta_time(), 0)
        
    tela.update()
    
    print(len(tela._objs))
    #print(f"{tela.fps():.0f} fps")
    

    