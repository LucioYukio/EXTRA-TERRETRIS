from math import cos, sin

from body import Screen
from nave import *
from pplay.keyboard import Keyboard
from pplay.sprite import Sprite
from screen import Mouse


class EnemyBullet(Bullet):
    def __init__(self, tab: int, mouse: Mouse, objs: list):
        super().__init__("assets/images/disparo_inimigo.png", tab, mouse, objs)
        self.tags.append("enemy_projectile")
        self.velocity.y = 200
        

class Enemy(Nave):
    def __init__(self, width: int, height: int, tab: int, mouse: Mouse, objs: list, keyboard: Keyboard, tela: Screen):
        super().__init__("assets/images/nave_inimiga.png", width, height, tab, mouse, objs, keyboard, tela)
        if "player" in self.tags:
            self.tags.remove("player")
        self.tags.append("enemy")
        self.damage_from_tags = {"player_projectile"}
        self.health = 3
        self.keep_in_bounds = False
        self.destroy_out_of_h_bounds = False
        self.destroy_out_of_v_bounds = True
        self.speed = 100
        self.shooting_interval = 2
        
        self.hitbox = Vector2(-1,-1)
        
    def get_direction(self):
        self.direction.y = 1
    
    def spawn_rastro(self):
        self.rastro : Rastro = self.screen.add_object(Rastro(self._tab, self._mouse, 8, self.screen))

    def apply_rastro_offset(self):
        try:
            self.rastro
        except:
            self.spawn_rastro()
        self.rastro.offset = Vector2(self.get_width()/2, 0)
    
    def check_shoot(self):
        if self.shooting_cooldown <= 0:
            self.shoot()
            self.shooting_cooldown = self.shooting_interval
            
    def shoot(self):
        self.bullets.append(self.screen.add_object(EnemyBullet(self._tab, self._mouse, self.objs)))
        self.bullets[-1].x = self.x + self.get_width()/2 - self.bullets[-1].get_width()/2
        self.bullets[-1].y = self.y + self.get_height() - 5

class EnemySin(Enemy):
    """Inimigo com um padrao de movimento horizontal seno"""
    def __init__(self, width: int, height: int, tab: int, mouse: Mouse, objs: list, keyboard: Keyboard, tela: Screen):
        super().__init__(width, height, tab, mouse, objs, keyboard, tela)
        self.sin_speed : float = 1
    
    def get_direction(self):
        self.direction.y = 1
        self.direction.x = cos(self._animation_time_elapsed * self.sin_speed)