from pplay.sprite import Sprite
from screen import *
from screen import Mouse

class Text(Object):
    def __init__(self, tab: int, mouse: Mouse):
        super().__init__(s.Sprite("images/black_pixel.png"), tab, mouse)
        # serao desenhados em sequencia na tela
        self.texts : List = []
        self.size : int = 12
        self.color = "white"
    
    def get_text(self):
        return "".join([str(txt) for txt in self.texts])
    
    def render(self, window: w.Window):
        window.draw_text(self.get_text(), self.x, self.y, self.size, self.color)
            